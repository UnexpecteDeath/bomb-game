import dollar from "../../images/dollar.svg"
import bomb from "../../images/bomb.svg"
import style from "./index.module.css"
import React from 'react';

export function Section({ bombs,  mines }) {

    return (
        <section className={style.gameBar}>
            <div className={style.dollars}><img className={style.dollar} src={dollar} alt=""></img><p className={style.countDollars}>{25 - bombs}</p></div>
            <div id={style.death}></div>
            <div className={style.minefield}>{mines.map((item, index) => (<React.Fragment key={index}>{item}</React.Fragment>))}</div>
            <div className={style.bombs}><img className={style.bomb} src={bomb} alt=""></img><p className={style.countBombs}>{ bombs }</p></div>
        </section>
    )
}