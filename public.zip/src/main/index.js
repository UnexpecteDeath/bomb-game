import { Aside } from "./aside"
import style from "./index.module.css"
import { Section } from "./section"
import death from "../images/death.svg"
import dollar from "../images/dollar-bill.svg"
import { useState } from 'react';
import styleSection from "../main/section/index.module.css"
export function Main({setBombs, bombs}) {
    const [mines, setMines] = useState([]);
    const [isVisible, SetVisible] =useState([]);
    function render() {
        const newMines = [];
        let random = getRandomInt(1, 25, bombs)
        for(let i = 0; i < 25; i++) {
            const explosion = random.indexOf(i) !== -1;
            newMines.push(
                <div className={styleSection.mine}><img src={explosion ? death : dollar} alt="mine" className={styleSection.mineImg}></img></div>
            )
        }
        setMines([...mines,...newMines])
    }


    function getRandomInt(min, max, count) {
        let uniqueSet = new Set();
        while (uniqueSet.size < count) {
            const num = Math.floor(Math.random() * (max - min + 1)) + min;
            uniqueSet.add(num);
        }
        return Array.from(uniqueSet);
    }

    return (
        <main>
            <Aside setBombs={setBombs} render={render}/>
            <Section bombs={bombs} mines={mines}/>
        </main>
    )
}