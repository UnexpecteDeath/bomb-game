import style from "./index.module.css"

export function Aside({ setBombs, render }) {



    return (
            <aside className={style.setBar}>
                <p className={style.betAmount}>Bet amount</p>
                <input className={style.betAmountInput} type="number"></input>
                <p className={style.numberOfBombs}>Number of bombs</p>
                <div className={style.bombsBtns}>
                    <button id="3bombs" onClick={() => setBombs(3)}>3</button>
                    <button id="5bombs" onClick={() => setBombs(5)}>5</button>
                    <button id="10bombs" onClick={() => setBombs(10)}>10</button>
                    <button id="24bombs" onClick={() => setBombs(24)}>24</button>
                </div>
                <button id={style.play} onClick={render}>Play</button>
                <button id={style.take}>Select cell</button>
            </aside>
    )
}